﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class Admin_AddStaff : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(Server.MapPath("~/image/") + FileUpload1.FileName);
            Image1.ImageUrl = "~/image/" + FileUpload1.FileName;
            Label15.Text = "Record Added Successfully.";
        }
        else
        {
            Label15.Text = "Record Added Not Successfully.";
        }
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        com = con.CreateCommand();
        String fnm = FileUpload1.FileName.ToString();
        String path = "~/image/";
        String upath = path + fnm;
        com.CommandText = "insert into Staff values(@a,@b,@c,@d,@e,@f)";
        com.Parameters.AddWithValue("@a", upath);
        com.Parameters.AddWithValue("@b", TextBox1.Text);
        com.Parameters.AddWithValue("@c", TextBox2.Text);
        com.Parameters.AddWithValue("@d", TextBox3.Text);
        com.Parameters.AddWithValue("@e", TextBox4.Text);
        com.Parameters.AddWithValue("@f", TextBox6.Text);
        con.Open();
        int res = com.ExecuteNonQuery();
        con.Close();
        FileUpload1.FileName.ToString();
        TextBox1.Text = " ";
        TextBox2.Text = " ";
        TextBox3.Text = " ";
        TextBox4.Text = " ";
        TextBox6.Text = " ";
        if ((TextBox8.Text == "mukul" || TextBox8.Text == "henil") && (TextBox9.Text == "......"))
        {
            Session["User Name:"] = TextBox8.Text;
            Session["Password:"] = TextBox9.Text;
            Response.Redirect("/Admin/StaffReport.aspx");
        }
    }
}