﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Admin_AddStandard : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        com = con.CreateCommand();
        com.CommandText = "insert into Standard values(@a,@b,@c)";
        com.Parameters.AddWithValue("@a", TextBox1.Text);
        com.Parameters.AddWithValue("@b", TextBox2.Text);
        com.Parameters.AddWithValue("@c", TextBox3.Text);
        con.Open();
        com.ExecuteNonQuery();
        con.Close();
        Label3.Text = "Standard Added Successfully.";
        GridView1.DataBind();
    }
    protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
        Label3.Text = "Record Updated Successfully.";
    }
}