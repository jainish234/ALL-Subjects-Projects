﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write(Session["txtunm"]);
        Response.Write(Session["txtpsw"]);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if ((txtunm.Text == "admin" || txtunm.Text == "Admin1") && (txtpsw.Text == "..."))
        {
            Session["username"] = txtunm.Text;
            Session["userpass"] = txtpsw.Text;
            Response.Redirect("/Admin/AddStandard.aspx");
        }
        else
        {
            Label2.Text = "Invalid Detail";
        }
    }

    protected void lnkbtn_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Home.aspx");
    }
}