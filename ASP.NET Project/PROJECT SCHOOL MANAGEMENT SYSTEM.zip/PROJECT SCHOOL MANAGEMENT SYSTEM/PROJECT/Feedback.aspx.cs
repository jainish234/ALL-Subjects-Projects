﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Feedback : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnfeedback_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        com = con.CreateCommand();
        com.CommandText = "insert into Feedback values(@a,@b,@c)";
        com.Parameters.AddWithValue("@a", TextBox5.Text);
        com.Parameters.AddWithValue("@b", TextBox6.Text);
        com.Parameters.AddWithValue("@c", TextBox7.Text);
        con.Open();
        com.ExecuteNonQuery();
        con.Close();
        Label13.Text = "Feedback Sent!!";
    }
}