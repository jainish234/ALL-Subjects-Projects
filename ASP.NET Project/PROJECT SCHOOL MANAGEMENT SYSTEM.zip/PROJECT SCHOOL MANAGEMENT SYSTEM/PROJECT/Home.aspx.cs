﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write(Session["txtusername"]);
        Response.Write(Session["txtpwd"]);
    }

    protected void Button8_Click(object sender, EventArgs e)
    {
        if ((txtusername.Text=="manish"||txtusername.Text == "mukul") && (txtpwd.Text == "......"))
        {
            Session["username"] = txtusername.Text;
            Session["userpass"] = txtpwd.Text;
            Response.Redirect("/StaffLogin/Default.aspx");
        }
        else
        {
            Label8.Text = "Login Error!!";
        }
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        if ((txt1unm.Text == "jainish" || txt1unm.Text == "raj") && (txt2pwd.Text == "........"))
        {
            Session["username"] = txt1unm.Text;
            Session["userpass"] = txt2pwd.Text;
            Response.Redirect("/StudentLogin/Main.aspx");
        }
        else
        {
            Label4.Text = "Login Error!!";
        }
    }
    
}