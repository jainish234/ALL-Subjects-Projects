﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class StaffLogin_AddStudent : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    protected void Page_Load(object sender, EventArgs e)
    {
        Panel1.Visible = false;
    }
    protected void Button11_Click(object sender, EventArgs e)
    {
        Panel1.Visible=true;
        Label19.Text = "Select Value";
    }
    protected void Button12_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(Server.MapPath("~/image/") + FileUpload1.FileName);
            Image1.ImageUrl = "~/image/" + FileUpload1.FileName;
            Label18.Text = "Student Added";
        }
        else
        {
            Label18.Text = "Student Not Added";
        }
        String dob = DropDownList2.SelectedItem.Text + "/" + DropDownList3.SelectedItem.Text +"/" + DropDownList4.SelectedItem.Text;
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        com = con.CreateCommand();
        String snm = FileUpload1.FileName.ToString();
        String path = "~/image/";
        String upath = path + snm;
        com.CommandText = "insert into Student values(@a,@b,@c,@d,@e,@f,@g,@h,@i,@j,@k)";
        com.Parameters.AddWithValue("@a", upath);
        com.Parameters.AddWithValue("@b",Convert.ToInt32(TextBox1.Text));
        com.Parameters.AddWithValue("@c", TextBox2.Text);
        com.Parameters.AddWithValue("@d", TextBox3.Text);
        com.Parameters.AddWithValue("@e", TextBox4.Text);
        com.Parameters.AddWithValue("@f", dob);
        com.Parameters.AddWithValue("@g", TextBox5.Text);
        com.Parameters.AddWithValue("@h", TextBox6.Text);
        com.Parameters.AddWithValue("@i", TextBox7.Text);
        com.Parameters.AddWithValue("@j", TextBox8.Text);
        com.Parameters.AddWithValue("@k", TextBox9.Text);
        con.Open();
        int res = com.ExecuteNonQuery();
        con.Close();
        FileUpload1.FileName.ToString();
        TextBox1.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = "";
        TextBox9.Text = "";
        Response.Redirect("/StaffLogin/AdvanceReport.aspx?StudentName="+TextBox2.Text);
        TextBox2.Text = "";
    }
}