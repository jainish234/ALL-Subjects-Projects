﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class StaffLogin_AdvanceReport : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Panel1.Visible = false;
    }
    protected void Button11_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        Label11.Text = "Select Value";
    }
    protected void Button12_Click(object sender, EventArgs e)
    {
        Label12.Text = "Student Promoted";
        //Response.Redirect("/StaffLogin/StudentReport.aspx");
    }
}