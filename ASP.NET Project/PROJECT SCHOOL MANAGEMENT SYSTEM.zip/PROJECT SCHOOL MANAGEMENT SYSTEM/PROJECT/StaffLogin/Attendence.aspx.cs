﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class StaffLogin_Attendence : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand com;
    protected void Page_Load(object sender, EventArgs e)
    {
        GridView1.Visible = false;
        Label6.Visible = false;
    }
    protected void Button11_Click(object sender, EventArgs e)
    {
        GridView1.Visible = true;
    }
    protected void Button12_Click(object sender, EventArgs e)
    {
        Label6.Visible = true;
        Label6.Text = "Attendence Saved";
    }
}