﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class StaffLogin_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string strconn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        //string mainconn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        //SqlConnection con = new SqlConnection(mainconn);
        //string sqlquery = "select Photo from Student where Sid='"+Session["username"]+"'";
        //SqlCommand cmd = new SqlCommand(sqlquery, con);
        //con.Open();
        //SqlDataReader sdr = cmd.ExecuteReader();

        //if (sdr.Read())
        //{
        //    Session.Clear();
        //    Session.RemoveAll();
        //    string imgname=sdr["Photo"].ToString();
        //    Master.imguser.ImageUrl=imgname;
        //}
        //else
        //{
        //    Response.Redirect("Default.aspx");
        //}
    }

    protected void Button12_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(Server.MapPath("~/image/") + FileUpload1.FileName);
            Label12.ForeColor = System.Drawing.Color.Green;
            Label12.Text = "Image added successfully!!";
            Image3.ImageUrl = "~/image/" + FileUpload1.FileName;
        }
        else
        {
            Label12.ForeColor = System.Drawing.Color.Red;
            Label12.Text = "select image first!!";
        }
    }

    //protected void btnUpdate_Click(object sender, EventArgs e)
    //{
    //    if (FileUpload1.PostedFile != null)
    //    {
    //        string strpath = Path.GetExtension(FileUpload1.FileName);
    //        if (strpath != ".jpg" && strpath != ".jpeg" && strpath != "gif" && strpath != ".png")
    //        {
    //            Label1.Text = "Only image files allowed(jpg,jpeg,gif,png)!";
    //            Label1.ForeColor = System.Drawing.Color.Red;
    //        }

    //        string fileimg = Path.GetFileName(FileUpload1.PostedFile.FileName);
    //        FileUpload1.SaveAs(Server.MapPath("~/image/") + fileimg);

    //        string mainconn = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    //        SqlConnection con = new SqlConnection(mainconn);
    //        string sqlquery = "update Student set Photo='" + "~/image/" + fileimg + "' where Sid='" + Master.lblusername.Text + "'";
    //        con.Open();
    //        SqlCommand cmd = new SqlCommand(sqlquery, con);
    //        cmd.Parameters.AddWithValue("@Photo", "~/image/" + fileimg);
    //        cmd.ExecuteNonQuery();
    //        Label1.Text = "User Profile Image" + Master.lblusername.Text + "Is Updated Successfull!!";
    //    }
    //    else
    //    {
    //        Label1.Text = "Failed to update the user image!";
    //    }
    //}
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand("update Student set Photo=@Photo where Sid=@Sid", con);
        cmd.Parameters.AddWithValue("@txtemail", txtemail.Text);
        cmd.Parameters.AddWithValue("@txtmobile", txtmobile.Text);
        cmd.Parameters.AddWithValue("@txtadd", txtadd.Text);
        cmd.Parameters.AddWithValue("@txtct", txtct.Text);
        cmd.Parameters.AddWithValue("@txtpincode", txtpincode.Text);

        string img = "";
        if (FileUpload2.HasFile)
        {
            string pic = "~/image/";
            img = pic + FileUpload2.FileName;
            FileUpload2.SaveAs(Server.MapPath(img));
            Image2.ImageUrl = img;
            Label13.Text = "Image Updated Successfully";

            cmd.Parameters.AddWithValue("@Photo", img);
        }
        else 
        {
            cmd.Parameters.AddWithValue("@Photo", Label13.Text);
        }
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        //da.Fill(ds);
    }
}

       

