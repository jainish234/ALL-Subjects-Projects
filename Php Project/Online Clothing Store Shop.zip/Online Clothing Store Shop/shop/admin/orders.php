<?php
include '../db.php';

// Fetch all orders
$query = "SELECT * FROM orders";
$result = mysqli_query($con, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Orders - Admin Panel</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
        .badge {
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 13px;
            color: white;
        }
        .badge-success { background-color: #28a745; }
        .badge-danger { background-color: #dc3545; }
        .badge-info { background-color: #17a2b8; }
        .badge-warning { background-color: #ffc107; color: black; }
    </style>
</head>
<body>
    <h2>Orders / Page orders</h2>
    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>Ref</th>
            <th>Order</th>
            <th>Customer Info</th>
            <th>Status</th>
            <th>Action</th>
        </tr>

        <?php
        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <tr>
                <td><?php echo $row['ref_id']; ?></td>

                    <td><a href="#">Orders</a></td>
                    <td>
                        Name: <?php echo $row['customer_name']; ?><br>
                        Address: <?php echo $row['customer_address']; ?><br>
                        Email: <?php echo $row['customer_email']; ?><br>
                        Contact #: <?php echo $row['customer_contact']; ?>
                    </td>
                    <td>
                        <span class="badge badge-success"><?php echo ucfirst($row['status']); ?></span>
                    </td>
                    <td>
                        <button class="updateStatus badge badge-success" data-id="<?php echo $row['order_id']; ?>" data-status="Delivered">
                            Delivered
                        </button>
                    </td>
                </tr>
                <?php
            }
        } else {
            echo "<tr><td colspan='5'>No orders found.</td></tr>";
        }
        ?>
    </table>

    <script>
    $(document).ready(function(){
        $('.updateStatus').click(function(){
            var id = $(this).data('id');
            var status = $(this).data('status');

            $.ajax({
                url: 'orderstatsupdate.php',
                type: 'POST',
                data: {id: id, status: status},
                success: function(response){
                    if(response == 1){
                        alert('Status Updated to Delivered!');
                        location.reload(); // Refresh to reflect changes
                    } else {
                        alert('Failed to update status.');
                    }
                }
            });
        });
    });
    </script>
</body>
</html>
