<?php
include '../db.php'; // Database connection

extract($_POST); // Get 'id' and 'status' from POST

// Update the order status
$update = mysqli_query($con, "UPDATE orders SET status = '$status' WHERE order_id = $id");

if ($update)
    echo 1; // Success
else
    echo 0; // Failure
?>
