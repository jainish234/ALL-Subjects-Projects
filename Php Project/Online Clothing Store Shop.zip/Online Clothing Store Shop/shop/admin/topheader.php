<nav class="navbar navbar-light fixed-top bg-primary" >
  <div class="container-fluid mt-2 ">
    <div class="col-lg-12">
        <!-- <img src="" class="float-left" alt="" width="35" height="35"> -->
      <div class="col-md-4 float-left">
        <h4 class="text-white">Online Clothes Store - Admin Side</h4>
      </div>
      <div class="col-md-2 float-right">
        <a href="logout.php" class=" text-white"><?php echo $_SESSION['login_admin_name'] ?> <i class="fa fa-power-off"></i></a>
      </div>
    </div>
  </div>
  
</nav>