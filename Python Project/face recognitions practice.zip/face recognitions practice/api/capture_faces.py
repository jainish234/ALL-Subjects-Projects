# api/capture_faces.py
import cv2
import os

name = input("Enter your name: ")
folder_path = f"dataset/{name}"

if not os.path.exists(folder_path):
    os.makedirs(folder_path)

cap = cv2.VideoCapture(0)

for i in range(10):  # Capture 10 images
    ret, frame = cap.read()
    if not ret:
        break
    cv2.imwrite(f"{folder_path}/{name}_{i}.jpg", frame)
    cv2.imshow("Capturing", frame)
    cv2.waitKey(200)

cap.release()
cv2.destroyAllWindows()
