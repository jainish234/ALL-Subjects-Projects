# api/database.py
import mysql.connector

def get_db_connection():
    return mysql.connector.connect(host="localhost", user="root", password="password", database="attendance_db")

def mark_attendance(name):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(f"INSERT INTO attendance (name, timestamp) VALUES ('{name}', NOW())")
    conn.commit()
    conn.close()
