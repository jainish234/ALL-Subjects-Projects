# app.py
from flask import Flask, request, jsonify
from api.database import mark_attendance

app = Flask(__name__)

@app.route('/attendance', methods=['POST'])
def record_attendance():
    data = request.json
    name = data.get('name')
    mark_attendance(name)
    return jsonify({"message": "Attendance recorded"})

if __name__ == '__main__':
    app.run(debug=True)
