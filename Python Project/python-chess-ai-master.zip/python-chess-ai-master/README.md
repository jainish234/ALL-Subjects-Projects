# Chess AI

## Instructions

- Entry point: main.py
- Change gamemode with key 'a' (pvp or ai)
- Change AI depth with keys '3' or '4'
- Change theme with key 't' (green, brown, blue, grey, cs)
- Restar the game with key 'r'
