class Color:
    '''
        Stores color data (light and dark)
    '''
    
    def __init__(self, light, dark):
        self.light = light
        self.dark = dark