# ---------
# CONSTANTS
# ---------

# Screen dimensions
WIDTH = 800
HEIGHT = 800

# Board dimensions
COLS = 8
ROWS = 8
SQSIZE = WIDTH // COLS